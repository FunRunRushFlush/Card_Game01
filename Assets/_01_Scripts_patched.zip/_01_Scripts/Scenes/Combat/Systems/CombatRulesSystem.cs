using UnityEngine;

public class CombatRulesSystem : Singleton<CombatRulesSystem>
{
    [SerializeField] private CombatRulesSO rules;
    public CombatRulesSO Rules => rules;

    private void Awake()
    {
        if (rules == null)
            Debug.LogError("[CombatRulesSystem] Missing CombatRulesSO reference.");
    }
}
public class RefillManaGA : GameAction
{
}
